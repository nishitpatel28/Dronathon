/*
 Pluto X API V.0.1
 */

#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


uint32_t microsT(void);

#ifdef __cplusplus
}
#endif
