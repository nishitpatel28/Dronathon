/*
 Pluto X API V.0.1
 */

#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


class AccelerometerClass {
    public:

        int16_t getX(void);
        int16_t getY(void);
        int16_t getZ(void);
};

class GyroscopeClass {
    public:

        int16_t getX(void);
        int16_t getY(void);
        int16_t getZ(void);
};

class MagnetometerClass {
    public:

        int16_t getX(void);
        int16_t getY(void);
        int16_t getZ(void);
};

class BarometerClass {
    public:

        int32_t getPressure(void);
        int32_t getTemperature(void);
};



extern AccelerometerClass Accelerometer;
extern GyroscopeClass Gyroscope;
extern MagnetometerClass Magnetometer;
extern BarometerClass Barometer;


#ifdef __cplusplus
}
#endif
