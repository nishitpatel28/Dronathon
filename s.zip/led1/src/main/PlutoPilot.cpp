// Do not remove the include below
#include "PlutoPilot.h"
#include "althold.h"
#include "sensor.h"
#include "led.h"
#include "control.h"
#include "print.h"

int velocity;
//The setup function is called once at Pluto's hardware startup
void plutoInit()
{
// Add your hardware initialization code here
}



//The function is called once before plutoFly when you activate UserCode
void onPilotStart()
{
  // do your one time stuffs here
	velocity=0;
	Control.disableFlightStatus(true);
	ledOp(L_LEFT, OFF);
	ledOp(L_RIGHT, OFF);
	ledOp(L_MID, OFF);
}



// The loop function is called in an endless loop
void plutoPilot()
{

//Add your repeated code here
	velocity=Althold.getVelocityZ();
	if(velocity>0)
	{
		ledOp(L_LEFT,ON);
		ledOp(L_RIGHT,OFF);
	}
	else
		{
			ledOp(L_LEFT,OFF);
			ledOp(L_RIGHT,ON);
		}
	printInt("net Acc:",Accelerometer.getZ());
	printRG(Accelerometer.getZ(), 100);
}



//The function is called once after plutoFly when you deactivate UserCode
void onPilotFinish()
{

	 // do your cleanup stuffs here
	Control.disableFlightStatus(false);
}




